import React, { useEffect, useMemo, useState } from 'react';
import MeatScreenShell from './components/MeatScreenShell';
import AgarthaumLogo from './components/AgarthaumLogo';
import SessionGrid from './components/SessionGrid';
import CreateSessionModal from './components/CreateSessionModal';
import { loadSessions, saveSessions } from './lib/storage';
import { verifySpotifyUrl } from './lib/api';

const DEFAULT_TARGET = 'https://open.spotify.com/artist/0st0X9claBghQXyhzbBaVR?si=SOifsUc1STGb8XGAuD3CpQ&utm_source=copy-link';

function makeId() {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID();
  return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

export default function App() {
  const [sessions, setSessions] = useState(() => loadSessions());
  const [showCreate, setShowCreate] = useState(false);
  const [filter, setFilter] = useState('');

  useEffect(() => {
    saveSessions(sessions);
  }, [sessions]);

  const hasLiveSessions = sessions.some((session) => session.status === 'live');

  const visibleSessions = useMemo(() => {
    const query = filter.trim().toLowerCase();
    if (!query) return sessions;
    return sessions.filter((session) =>
      session.name.toLowerCase().includes(query) || session.spotifyUrl.toLowerCase().includes(query)
    );
  }, [sessions, filter]);

  function createSession({ name, spotifyUrl }) {
    const session = {
      id: makeId(),
      name,
      spotifyUrl,
      status: 'idle',
      createdAt: new Date().toISOString(),
      lastCheckedAt: null,
      message: 'Ready for verification.',
    };
    setSessions((current) => [session, ...current]);
    setShowCreate(false);
  }

  async function checkSession(id) {
    const current = sessions.find((session) => session.id === id);
    if (!current) return;

    setSessions((all) => all.map((session) =>
      session.id === id ? { ...session, status: 'checking', message: 'Contacting verification backend…' } : session
    ));

    try {
      const result = await verifySpotifyUrl(current.spotifyUrl);
      const status = result.status === 'live' ? 'live' : 'error';
      setSessions((all) => all.map((session) =>
        session.id === id
          ? {
              ...session,
              status,
              lastCheckedAt: new Date().toISOString(),
              message: result.message || `HTTP ${result.httpStatus ?? 'unknown'}`,
            }
          : session
      ));
    } catch (error) {
      setSessions((all) => all.map((session) =>
        session.id === id
          ? { ...session, status: 'error', lastCheckedAt: new Date().toISOString(), message: error.message }
          : session
      ));
    }
  }

  function deleteSession(id) {
    setSessions((all) => all.filter((session) => session.id !== id));
  }

  return (
    <MeatScreenShell>
      <AgarthaumLogo hasLiveSessions={hasLiveSessions} />

      <section className="dashboard-head">
        <div>
          <div className="section-kicker">UNIVERSAL SESSION CONTROL</div>
          <h1>Session Matrix</h1>
          <p>{sessions.length} persistent node{sessions.length === 1 ? '' : 's'} stored on this device.</p>
        </div>
        <button className="create-button" onClick={() => setShowCreate(true)}>＋ Create New</button>
      </section>

      <section className="toolbar">
        <div className="system-status">
          <span className={`system-light ${hasLiveSessions ? 'active' : ''}`} />
          {hasLiveSessions ? 'SYSTEM ACTIVE' : 'SYSTEM STANDBY'}
        </div>
        <input
          className="search-input"
          value={filter}
          onChange={(event) => setFilter(event.target.value)}
          placeholder="Search sessions…"
          aria-label="Search sessions"
        />
      </section>

      <SessionGrid sessions={visibleSessions} onCheck={checkSession} onDelete={deleteSession} />

      <footer className="dashboard-footer">
        <span>BBØ BROWSER LAB</span>
        <span>V3.0.0</span>
        <button className="seed-button" onClick={() => setShowCreate(true)} title="Create a session using the standard Spotify target">Use default target</button>
      </footer>

      {showCreate && (
        <CreateSessionModal
          onClose={() => setShowCreate(false)}
          onCreate={(data) => createSession({ ...data, spotifyUrl: data.spotifyUrl || DEFAULT_TARGET })}
        />
      )}
    </MeatScreenShell>
  );
}
