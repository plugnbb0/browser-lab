import React from 'react';

export default function AgarthaumLogo({ hasLiveSessions }) {
  return (
    <header className={`agarthaum-header ${hasLiveSessions ? 'is-live' : ''}`}>
      <div className="logo-kicker">BBØ // BROWSER LAB</div>
      <div className="agarthaum-logo" aria-label="AGARTHAUM">AGARTHAUM</div>
      <div className="logo-subtitle">VOLUME 03 · UNIVERSAL SESSION CONTROL</div>
    </header>
  );
}
