import React from 'react';
import SessionCard from './SessionCard';

export default function SessionGrid({ sessions, onCheck, onDelete }) {
  if (!sessions.length) {
    return (
      <section className="empty-state">
        <div className="empty-glyph">◎</div>
        <h2>No sessions yet</h2>
        <p>Create your first session node to begin URL verification.</p>
      </section>
    );
  }

  return (
    <section className="session-grid" aria-label="Browser sessions">
      {sessions.map((session) => (
        <SessionCard
          key={session.id}
          session={session}
          onCheck={() => onCheck(session.id)}
          onDelete={() => onDelete(session.id)}
        />
      ))}
    </section>
  );
}
