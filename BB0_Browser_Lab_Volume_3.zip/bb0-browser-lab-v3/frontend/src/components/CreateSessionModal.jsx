import React, { useState } from 'react';

export default function CreateSessionModal({ onClose, onCreate }) {
  const [name, setName] = useState('');
  const [spotifyUrl, setSpotifyUrl] = useState('');
  const [error, setError] = useState('');

  function submit(event) {
    event.preventDefault();
    setError('');

    if (!name.trim()) {
      setError('Give this session a name.');
      return;
    }

    try {
      const parsed = new URL(spotifyUrl.trim());
      const host = parsed.hostname.toLowerCase().replace(/^www\./, '');
      if (parsed.protocol !== 'https:' || !['open.spotify.com', 'spotify.com'].includes(host)) {
        throw new Error();
      }
    } catch {
      setError('Enter a valid https://open.spotify.com/... URL.');
      return;
    }

    onCreate({ name: name.trim(), spotifyUrl: spotifyUrl.trim() });
  }

  return (
    <div className="modal-backdrop" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
      <section className="create-modal" role="dialog" aria-modal="true" aria-labelledby="create-title">
        <div className="modal-eyebrow">NEW CONTROL NODE</div>
        <h2 id="create-title">Create New Session</h2>
        <p className="modal-description">Create a persistent session record. Verification checks the Spotify URL only.</p>

        <form onSubmit={submit}>
          <label>
            Session name
            <input autoFocus value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Main Node" maxLength={80} />
          </label>
          <label>
            Spotify URL
            <input value={spotifyUrl} onChange={(e) => setSpotifyUrl(e.target.value)} placeholder="https://open.spotify.com/track/..." inputMode="url" />
          </label>

          {error && <div className="form-error">{error}</div>}

          <div className="modal-actions">
            <button type="button" className="secondary-action" onClick={onClose}>Cancel</button>
            <button type="submit" className="primary-action">Create Session</button>
          </div>
        </form>
      </section>
    </div>
  );
}
