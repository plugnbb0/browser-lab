import React from 'react';

export default function MeatScreenShell({ children }) {
  return (
    <div className="meat-shell">
      <div className="meat-ridge meat-ridge-top" aria-hidden="true" />
      <div className="meat-ridge meat-ridge-left" aria-hidden="true" />
      <div className="meat-ridge meat-ridge-right" aria-hidden="true" />
      <div className="meat-ridge meat-ridge-bottom" aria-hidden="true" />
      <div className="meat-veins" aria-hidden="true" />
      <main className="control-panel">{children}</main>
    </div>
  );
}
