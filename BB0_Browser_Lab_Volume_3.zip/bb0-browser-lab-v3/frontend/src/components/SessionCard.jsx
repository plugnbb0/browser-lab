import React from 'react';

const statusLabels = {
  idle: 'Idle',
  checking: 'Checking',
  live: 'Live',
  error: 'Error',
};

function formatDate(value) {
  if (!value) return 'Never';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return 'Unknown';
  return date.toLocaleString([], { dateStyle: 'short', timeStyle: 'short' });
}

export default function SessionCard({ session, onCheck, onDelete }) {
  const disabled = session.status === 'checking';

  return (
    <article className={`session-card status-${session.status}`}>
      <div className="session-card-glow" aria-hidden="true" />
      <div className="session-card-topline">
        <span className="session-id">NODE // {String(session.id).slice(-6).toUpperCase()}</span>
        <span className={`status-pill ${session.status}`}>
          <span className="status-dot" />
          {statusLabels[session.status] || 'Unknown'}
        </span>
      </div>

      <div className="session-name">{session.name}</div>
      <div className="session-url" title={session.spotifyUrl}>{session.spotifyUrl}</div>

      <div className="session-meta">
        <span>LAST CHECK</span>
        <strong>{formatDate(session.lastCheckedAt)}</strong>
      </div>

      {session.message && <div className="session-message">{session.message}</div>}

      <div className="session-actions">
        <button className="primary-action" onClick={onCheck} disabled={disabled}>
          {disabled ? 'Checking…' : 'Check Now'}
        </button>
        <button className="delete-action" onClick={onDelete} disabled={disabled} aria-label={`Delete ${session.name}`}>
          ×
        </button>
      </div>
    </article>
  );
}
