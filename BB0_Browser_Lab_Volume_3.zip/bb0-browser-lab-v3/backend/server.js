import express from 'express';
import cors from 'cors';

const app = express();
const PORT = process.env.PORT || 3000;
const FRONTEND_ORIGIN = process.env.FRONTEND_ORIGIN || '*';
const MAX_BODY_BYTES = '16kb';
const REQUEST_TIMEOUT_MS = 12000;

app.use(cors({
  origin: FRONTEND_ORIGIN === '*' ? true : FRONTEND_ORIGIN.split(',').map((value) => value.trim()),
  methods: ['GET', 'POST'],
  allowedHeaders: ['Content-Type'],
}));
app.use(express.json({ limit: MAX_BODY_BYTES }));

function isAllowedSpotifyUrl(rawUrl) {
  let parsed;
  try {
    parsed = new URL(rawUrl);
  } catch {
    return false;
  }

  if (parsed.protocol !== 'https:') return false;

  const host = parsed.hostname.toLowerCase().replace(/^www\./, '');
  return host === 'open.spotify.com' || host === 'spotify.com';
}

async function fetchWithTimeout(url) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

  try {
    // Redirects are followed by fetch, but the initial input is restricted to Spotify hosts.
    return await fetch(url, {
      method: 'GET',
      redirect: 'follow',
      signal: controller.signal,
      headers: {
        'User-Agent': 'BB0-Browser-Lab-V3-Verifier/3.0',
        'Accept': 'text/html,application/xhtml+xml',
      },
    });
  } finally {
    clearTimeout(timeout);
  }
}

app.get('/health', (_req, res) => {
  res.json({ status: 'ok', service: 'bb0-browser-lab-v3', version: '3.0.0' });
});

app.post('/verify', async (req, res) => {
  const url = typeof req.body?.url === 'string' ? req.body.url.trim() : '';

  if (!url) {
    return res.status(400).json({ status: 'error', httpStatus: 400, message: 'url is required.' });
  }

  if (!isAllowedSpotifyUrl(url)) {
    return res.status(400).json({
      status: 'error',
      httpStatus: 400,
      message: 'Only HTTPS Spotify URLs on open.spotify.com or spotify.com are allowed.',
    });
  }

  try {
    const response = await fetchWithTimeout(url);
    const live = response.status >= 200 && response.status < 400;

    return res.status(200).json({
      status: live ? 'live' : 'error',
      httpStatus: response.status,
      message: live ? 'Spotify URL is reachable.' : `Spotify returned HTTP ${response.status}.`,
    });
  } catch (error) {
    const message = error?.name === 'AbortError'
      ? 'Spotify request timed out.'
      : 'Spotify URL could not be reached from the verification backend.';

    return res.status(200).json({
      status: 'error',
      httpStatus: 0,
      message,
    });
  }
});

app.use((_req, res) => {
  res.status(404).json({ status: 'error', httpStatus: 404, message: 'Route not found.' });
});

app.listen(PORT, () => {
  console.log(`BBØ Browser Lab V3 backend listening on port ${PORT}`);
});
