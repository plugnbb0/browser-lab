# BBØ Browser Lab — Volume 3

A phone-manageable React + Express dashboard for persistent session records and Spotify URL reachability checks.

## Safety / scope

This version is a web control plane. It does not launch local browsers, automate Spotify playback, create accounts, manipulate streams, bypass platform controls, or evade detection. “Live” means the configured Spotify URL was reachable from the verification backend.

## Deploy backend

1. Put this repo on GitHub.
2. In Render, create a Web Service from the repo.
3. Set Root Directory to `backend`.
4. Build command: `npm install`
5. Start command: `npm start`
6. Optional environment variable: `FRONTEND_ORIGIN=https://YOUR-FRONTEND-DOMAIN.vercel.app`
7. Copy the deployed backend URL.

## Deploy frontend

1. Create a Vercel project from the same GitHub repo.
2. Set Root Directory to `frontend`.
3. Framework preset: Vite.
4. Build command: `npm run build`.
5. Output directory: `dist`.
6. Before using verification, open `frontend/src/lib/api.js` and replace `https://YOUR-BACKEND-URL.onrender.com` with the deployed backend URL.

Netlify works similarly: use `frontend` as the base directory, `npm run build` as the build command, and `dist` as the publish directory.
